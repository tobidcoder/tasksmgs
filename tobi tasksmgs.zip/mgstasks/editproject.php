<?php 
require_once("include/autoload.php");
include 'include/header.php';
$id = isset($_GET['id']);
$id = ($_GET['id']);
$projectedit = new Project();
$db = new Db();
$viewpro = new Project();

if(ISSET($_POST['updatepro'])){   
    $project_title =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['project_title']));
    $project_description =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['project_description']));
    $due_date =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['due_date']));
    $status =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['status']));
    
$result = $projectedit->editProject($id,$project_title,$project_description,$due_date,$status);
if($result){
  echo '<script> alert ("Project update successful")</script>';
  echo '<script>window.location = "viewproject.php"</script>';
}else{
  echo '<script> alert ("Something went wrong ")</script>';
  echo '<script>window.location = "viewproject.php"</script>';
}

}
?>
<?php 
  $view1 = $viewpro->viewProject1($id);
    foreach($view1 as $view){
   ?>
<form class="tobi-form" action="" method="POST">
  <h3> Update Project </h3>
  <!-- <div class="form-group">
    <label for="id"></label>
    <input type="text" class="form-control" hidden="hidden" name="id"  value="<?php echo htmlentities($view['id']); ?>" >
    </div> -->
      <div class="form-group">
    <label for="project_title">project title</label>
    <input type="text" class="form-control" name="project_title"  value="<?php echo htmlentities($view['project_title']); ?>" required="required">
    </div>
    <div class="form-group">
    <label for="project_description">project description</label>
    <input type="text" class="form-control" name="project_description"  value="<?php echo htmlentities($view['project_description']); ?>" required="required">
    </div>
    <br>
	<div class="form-group">
    <label for="due_date">Due Date</label>
    <input type="date" class="form-control" name="due_date" value="<?php echo htmlentities($view['due_date']); ?>" required="required">
    </div>
    <div class="form-group">
    <label for="status">Select Status</label>
    <select class="form-control" name="status" id="status">
    <option value="<?php echo $view['status']; ?>"><?php echo htmlentities($view['status']);?></option>
      <option>Pending</option>
      <option>Active</option>
      <option>Ongoing</option>
      <option>Completed</option>
      </select>
  </div>
  <?php } ?>
    <button type="submit" name="updatepro" class="btn btn-primary">Update Project</button> 
</form>


<?php include 'include/footer.php' ?>