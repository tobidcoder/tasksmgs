<?php 
class Admin extends Db {
	public $fullname;
	public $email;
 	public $username; 	
	public $password;
	
	public function createAccount($fullname,$email,$username,$password) {
		//Create account 
		$password = md5($password);
		$sql = "INSERT INTO admin(fullname,email,username,password) VALUES('$fullname','$email','$username','$password') ";
		$result =$this->connect()->query($sql);
		if($result){
			return true;

		}else{
			echo"";
		}
			}

	public function login($username,$password) {
		//Login admin
		$password = md5($password);
		$sqllog = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
		$result =$this->connect()->query($sqllog);
		if($result->num_rows > 0){
			$row = $result->fetch_array();
			return $row;
		}else{
			echo"";
		}
		
	}
	
	public function viewAlltasks(){
		
		$sql = "SELECT * FROM tasks";
		$result =$this->connect()->query($sql);
		return $result;		
	}
	public function viewAllpro (){
		$sql = "SELECT * FROM project";
		$result =$this->connect()->query($sql);
		return $result;
	}
}
?>

