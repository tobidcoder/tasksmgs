<?php 
class Project extends Db{
	public $project_title;
	public $project_description;
	public $due_date;
	public $status;
	public $connect;

	public function createProject ($project_title,$project_description,$due_date,$status){
		$userid = $_SESSION['id'];
		//Creating project
		$sql="INSERT INTO project (project_title,project_description,due_date,status,user_id) VALUES ('$project_title','$project_description','$due_date','$status','$userid')";
		$result =$this->connect()->query($sql) ;
		if($result){
			return true;
			{
				return false;
			}
		}
	}
	
	public function editProject ($id,$project_title,$project_description,$due_date,$status){	
		//Edit Project
		$sql2 = "UPDATE project SET project_title='$project_title', project_description='$project_description', due_date='$due_date', status='$status' WHERE id=$id";
		$result2 =$this->connect()->query($sql2);
		if($result2){
			return true;
		}else{
		 return false;
		}

	}

	public function deleteProjet ($id) {
		//Delete project methods
		$user_id = $_SESSION['id'];
		$sql ="SELECT * FROM project 
		INNER JOIN tasks 
		ON project.id=tasks.project_id
		WHERE project.user_id= $user_id AND tasks.project_id=$id";
		$result1 =$this->connect()->query($sql);
		$num = mysqli_num_rows($result1);
		if($num > 0){
			echo '<script> alert("Sorry, you can not delete project because it has tasks"); </script>';
			echo "<script> setTimeout(\"location.href='viewproject.php';\",15);</script>";
		}else {
		$sqlo = "DELETE FROM project WHERE id=$id AND user_id=$user_id";
		$result =$this->connect()->query($sqlo);
		if($result){
			return true;
		}else{
			return false;
		}
		}
	} 

	public function viewProject (){ 
		//View Project
		$user_id = $_SESSION['id'];
		$array = array();
	$sql3 = "SELECT * FROM project WHERE user_id = $user_id";
	$result =$this->connect()->query($sql3);	
	 while  ($row = mysqli_fetch_assoc($result)) {
		$array[] = $row; 		
	}
		return $array;		
		}

		/**
		 * View the details of a project
		 * 
		 * @param $id integer id of the project
		 * @return $array mixed array of project details
		 * 
		 */
	public function viewProject1 ($id){ 
			$array = array();
		$sql3 = "SELECT * FROM project WHERE id = $id";
		$result =$this->connect()->query($sql3);
		while ($row = mysqli_fetch_assoc($result)) {
			$array[] = $row;
		}	
		 return $array;
		}
	public function numofProject (){
		//Geting numbers of project for users
		$user_id =$_SESSION['id'];
		$sql = "SELECT * FROM project WHERE user_id=$user_id";
		$result =$this->connect()->query($sql);
		return $result;
	}
	
	}
?>

