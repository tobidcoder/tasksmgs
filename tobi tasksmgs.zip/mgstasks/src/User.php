<?php
// require_once("dbconfig.php");
class User extends Db {
	public $fname;
	public $lname;
	public $email;
	public $username;
	public $password;
	public $connect;

public function userRegister ($fname,$lname,$email,$username,$password){
	//Capture submited data
	$password =md5($password);
	$sql="INSERT INTO user (fname,lname,email,username,password) VALUES ('$fname','$lname','$email','$username','$password')";
	$result=$this->connect->query($sql);
	if($result){
		return true;
	}else {
		return false;
	}

}

public function login ($username,$password){ 
	
	$password = md5($password);
	$sql1= "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
	$query = $this->connect()->query($sql1);
		if($query->num_rows > 0){
				$row=$query->fetch_array();
				return $row;
		}
		else{
			return false;
		}
	}
public function isUser(){
	 if (isset($_SESSION['username']) && ($_SESSION['user_id']) == 'user'){
		 return true;

	 }else {
		 return false;
	 }
}
	
}	

?>
 