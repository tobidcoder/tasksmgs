<?php
class Tasks extends Db {
	public $tasks_title;
	public $tasks_description;
	public $project_id;
	public $tasks_status;	
	public $time_created;
	public $connect;

	public function createTasks ($tasks_title,$tasks_description,$project_id,$tasks_status){
		//Crete tasks 
		$user_id = $_SESSION['id'];	
		$sql="INSERT INTO tasks (tasks_title,tasks_description,project_id,tasks_status,user_id) VALUES ('$tasks_title','$tasks_description','$project_id','$tasks_status','$user_id')";
		$result=$this->connect()->query($sql);
		if($result){
			return true;
		}else {
			echo"";
		}
		}
	
	public function editTasks ($id,$tasks_title,$tasks_description,$tasks_status,$project_id){
		//Edit tasks 
		$sql = "UPDATE tasks SET tasks_title='$tasks_title',tasks_description='$tasks_description',tasks_status='$tasks_status',project_id='$project_id' WHERE tasks_id=$id ";
		$result =$this->connect()->query($sql);
		if($result){
			return true;
		}else{
			echo"";
		}

	}

	public function deleteTasks ($id){ 
		//Delete tasks methods
		$user_id = $_SESSION['id'];
		$sqldel = "DELETE FROM tasks WHERE tasks_id=$id AND user_id=$user_id";
		$resultdel =$this->connect()->query($sqldel);
		if($resultdel){
			return true;
		}else{
			return false;
		}
	} 

	public function viewTasks(){ 
		$array = array();
		$user_id = $_SESSION['id'];
		$sql ="SELECT * FROM tasks INNER JOIN project ON tasks.project_id=project.id
		WHERE project.user_id=$user_id";
		$result =$this->connect()->query($sql);
		
		while ($row = mysqli_fetch_assoc($result)){
		$array[] = $row;

		}
		return $array;
	}	
	public function viewTasks1 ($id){ 
		$array = array();		
		$sql2 = "SELECT * FROM tasks WHERE tasks_id=$id";
		$result=$this->connect()->query($sql2);		
		while ($row=mysqli_fetch_assoc($result)){
			 $array[] = $row;
		}
		return $array;
	}
	public function viewTaskspro ($project_id){ 
		$array = array();
		$user_id = $_SESSION['id'];
		$sql = "SELECT * FROM tasks INNER JOIN project ON tasks.project_id=project.id 
		WHERE project_id=$project_id AND project.user_id=$user_id";
		$result =$this->connect()->query($sql);

		while ($row = mysqli_fetch_assoc($result)){
			$array[] = $row;
		}
		return $array;
	}
	public function numofTasks(){
		$user_id = $_SESSION['id'];
		$sql = "SELECT * FROM tasks WHERE user_id=$user_id";
		$result=$this->connect()->query($sql);
		return $result;
	}
	public function numofTasksforProject ($id){
		$user_id = $_SESSION['id'];
		$sql = "SELECT project_id FROM tasks WHERE project_id= $id AND user_id=$user_id";
		$result =$this->connect()->query($sql);
		return $result;
	}	
	}
?>
