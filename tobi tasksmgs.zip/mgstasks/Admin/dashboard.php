
<?php
//die("I am here");
include 'include/header.php';
require_once("../include/autoload.php");

//Get number of Project
$project = new Admin();
$result = $project->viewAllpro();
$conting = mysqli_num_rows($result);
//Get number of Tasks
$tasks = new Admin();
$result = $tasks->viewAlltasks();
$count = mysqli_num_rows($result);
?>
<br>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h1 class="card-title">Project</h1>
        <h4 class="card-text">You have <b><?php echo $conting ;?></b> Projects.</h4>
        <br>        
        <a href="viewallpro.php" class="btn btn-primary">View Project</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h1 class="card-title">Tasks</h1>
        <h4 class="card-text">You have <b> <?php echo $count;?> </b> Tasks.</h4>
        <br>       
        <a href="viewalltasks.php" class="btn btn-primary">View Tasks</a>
      </div>
    </div>
  </div>
</div>
<?php include 'include/footer.php' ?>  