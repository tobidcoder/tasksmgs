<?php 
session_start();
require_once ("../include/autoload.php");

//Admin Login
// Escape user inputs for security
$adminlog = new Admin();
if(ISSET($_POST['login'])){
  $username =strip_tags(trim($_POST['username']));
  $password =strip_tags(trim($_POST['password']));

  if(empty($username) || empty($password)){
    header("location: login.php?error=emptyfield&username=".$username);
    exit();
  }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$username)){
    header("location: login.php?error=invalidusername");
    exit();
  } elseif(!preg_match("/^[a-zA-Z0-9]*$/",$password)){
    header("location: login.php?error=invalidpassword");
    exit();
  }else {
    $get_admin =$adminlog->login($username, $password);  
    $_SESSION['adminusername'] = $get_admin['username'];
    $_SESSION['adminid'] = $get_admin['id'];
    $_SESSION['fullname'] = $get_admin['fullname'];
      if($get_admin){	   
     echo '<script>alert("Successfully login!")</script>';
     echo '<script>window.location = "dashboard.php"</script>'; 
   }else{
    header("location: login.php?error=loginnotsucessful");
 }
  }
 
}
//Admin register
// Escape user inputs for security
$admin = new Admin();
if(ISSET($_POST['register'])){
  $fullname =strip_tags(trim($_POST['fullname']));
  $email =strip_tags(trim($_POST['email']));
  $username =strip_tags(trim($_POST['username']));
  $password =strip_tags(trim($_POST['password']));

  if(empty($fullname) || empty ($email) || empty($username) || empty($password)){
    header("location: register.php?error=emptyfield&fname=".$fname."&email=".$email."&username=".$username);
   exit();
  } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username)){
    header("location: register.php?error=Invalidfnamelnameemailusername");
    exit();
  }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("location: register.php?error=Invalidemail&fname=".$fname."&username=".$username);
   exit();
  }elseif(!preg_match("/^[A-Za-z]+([\ A-Za-z]+)*/",$fullname)){
    header("location: register.php?error=Invalidfirstname&email=".$email."&username=".$username);
   exit();  
  }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$username)){
    header("location: register.php?error=Invalidusername&fname=".$fname."&email=".$email);
  exit();
}else {
 $register=$admin->createAccount($fullname,$email,$username,$password);
  if($register){
    //If Registration is Valid
    header("location: register.php?sucess=registrationsucessful");
       }else{
      header("location: register.php?error=registernotsucess");
    }
}
}
?>