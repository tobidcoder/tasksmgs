<?php 
require_once("../include/autoload.php");
include 'include/header.php';
$viewalltasks = new Admin();
?>
<table class="table">
 <thead class="thead-dark">
 <br>
    <tr>     
      <th scope="col">Tasks Title</th>
      <th scope="col">Tasks Description</th>
      <th scope="col">Status</th>
     
      </tr>
  </thead>
  <tbody>
    <?php 
    $tasksview = $viewalltasks->viewAlltasks();
   while($row=mysqli_fetch_array($tasksview)){    
    ?>
    <tr>     
      <td><?php echo $row['tasks_title']; ?></td>
      <td><?php echo $row['tasks_description'];?></td>
      <td><?php echo $row['tasks_status']; ?></td>
      
     </tr>
    <?php  }  ?>    
  </tbody>
</table>

<?php include 'include/footer.php' ?>
   