<?php 
require_once("../include/autoload.php");
include 'include/header.php';
$viewallpro = new Admin();
?>
<table class="table">
 <thead class="thead-dark">
 <br>
    <tr>     
      <th scope="col">Project Title</th>
      <th scope="col">Project Description</th>
      <th scope="col">Due date </th>
      <th scope="col">Status</th>
     
      </tr>
  </thead>
  <tbody>
    <?php 
    $projectview = $viewallpro->viewAllpro ();
    while($row=mysqli_fetch_array($projectview)){    
    ?>
    <tr>     
      <td><?php echo $row['project_title']; ?></td>
      <td><?php echo $row['project_description'];?></td>
      <th><?php echo $row['due_date']; ?>  </td>
      <td><?php echo $row['status']; ?></td>
      
     </tr>
    <?php  }  ?>    
  </tbody>
</table>


 

<?php include 'include/footer.php' ?>
   