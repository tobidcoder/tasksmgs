<?php 
require_once("include/autoload.php");
include 'include/header.php';
$project = new Project();
$tasks = new Tasks();
?>
<table class="table">
  <thead class="thead-dark">
   <tr>     
    <br>
<a href="createproject.php"><button class="btn btn-primary btn-xs">Create Project<span class="glyphicon glyphicon-pencil"></span></button></a> </td>
 
      <th scope="col">Project Title</th>
      <th scope="col">Project Description</th>
      <th scope="col">Due Date</th>
      <th scope="col">Status </th>
      <th scope="col">No of Tasks</th>
      <th scope="col">View Tasks</th>
      <th scope="col">Edit </th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    //Get project 
    $projectview = $project->viewProject ();
    foreach ($projectview as $view){ 
      $id = $view['id'];
      $ide = base64_encode($id);
      //Get number of Tasks for each project
    $numoftasksproject = $tasks->numofTasksforProject($id);
    $num= mysqli_num_rows($numoftasksproject);
    ?>
    <tr>     
      <td><?php echo htmlentities($view['project_title']); ?></td>
      <td><?php echo htmlentities($view['project_description']);?></td>
      <td><?php echo htmlentities($view['due_date']); ?></td>
      <td><?php echo htmlentities($view['status']);?></td>
      <td><b><?php echo htmlentities($num)  ?></b></td>
      <td><a href="viewprotasks.php?proid=<?php echo htmlentities($view['id']);?>"><button class="btn btn-primary btn-xs">View Tasks<span class="glyphicon glyphicon-trash"></span></button></a></td>
      <td><a href="editproject.php?id=<?php echo htmlentities($view['id']);?>"><button class="btn btn-primary btn-xs">Edit<span class="glyphicon glyphicon-pencil"></span></button></a> </td>
      <td><a href="deleteproject.php?delp=<?php echo htmlentities($view['id']);?>"><button class="btn btn-danger btn-xs" onClick="return confirm('Do you really want to delete this Project?');">Delete<span class="glyphicon glyphicon-trash"></span></button></a></td>
        </tr>
    <?php  } ?>    
  </tbody>
</table>
<?php include 'include/footer.php' ?>
   