<?php
require_once("include/autoload.php");
include 'include/header.php';
$tasks = new Tasks();
$db = new Db();
if(isset($_GET['id']));
    $id = ($_GET['id']);
    $tasksview = $tasks->viewTasks1($id);
    foreach($tasksview as $view){       
        
if(ISSET($_POST['edittasks'])){
    $tasks_title =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['tasks_title']));
    $tasks_description =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['tasks_description']));
    $tasks_status =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['tasks_status']));
    $project_id =strip_tags(mysqli_real_escape_string($db->connect(), $_POST['project_id']));

if(empty($tasks_title) || empty($tasks_description) || empty($tasks_status)){
    header("location: edittasks.php?id=".$tasksid);
   
    exit();
}else {
    $updatetasks=$tasks->editTasks($id,$tasks_title,$tasks_description,$tasks_status,$project_id);
if($updatetasks){
    echo '<script> alert ("Tasks update successful")</script>';
    echo '<script>window.location = "viewtasks.php"</script>';
}else{
    
   }
} 
}
?>

<form class="tobi-form" action="" method="POST">
  <h3> Update Tasks </h3>  
    <div class="form-group">
    <label for="tasks_title">Tasks title</label>
    <input type="text" class="form-control" name="tasks_title"  value="<?php echo htmlentities($view['tasks_title']); ?>">
    </div>
    <div class="form-group">
    <label for="tasks_description">Tasks description</label>
    <input type="text" class="form-control" name="tasks_description"  value="<?php echo htmlentities($view['tasks_description']); ?>" >
    </div>
    <div class="form-group">
    <label for="status">Select Status</label>
    <select class="form-control" name="tasks_status" id="status">
    <option value="<?php echo $view['tasks_status']; ?>"><?php echo htmlentities($view['tasks_status']);?></option>
      <option>Pending</option>
      <option>Active</option>
      <option>Ongoing</option>
      <option>Completed</option>
      </select>
  </div>
  <div class="form-group">
  
    <input type="text" class="form-control" name="project_id" value="<?php echo htmlentities($view['project_id']); ?>" hidden>
    </div>
<?php }?>
    <button type="submit" name="edittasks" class="btn btn-primary">Update Tasks</button> 
</form>

<?php include 'include/footer.php'; ?>