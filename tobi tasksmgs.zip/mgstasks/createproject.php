<?php
 include 'include/header.php';
 require_once("include/autoload.php");
  //Create project
 $project = new Project(); 
 $db = new Db();
 if(ISSET($_POST['createpro'])){
     $project_title= strip_tags(mysqli_real_escape_string($db->connect(), $_POST['project_title']));
     $project_description = strip_tags(mysqli_real_escape_string($db->connect(), $_POST['project_description']));
     $due_date = strip_tags(mysqli_real_escape_string($db->connect(), $_POST['due_date']));
     $status = strip_tags(mysqli_real_escape_string($db->connect(), $_POST['status']));

     if(empty($project_title) || empty($project_description) || empty($due_date) || empty($status)){
        header("location: createproject.php?error=emptyfield");
            exit();
        }else {
            $addpro = $project->createProject($project_title,$project_description,$due_date,$status);
    if($addpro){
        echo '<script> alert ("Project created successful")</script>';
        echo '<script>window.location = "viewproject.php"</script>';
    } else {
            echo '<script> alert ("something went wrong, pleased try again")</script>';
            echo '<script>window.location="createproject.php"<script>';
        }
        }   
}
 ?>
<form class="tobi-form" action="" method="POST">
  <h3> Create Project </h3>
  <?php
if(isset($_GET['error'])){
    if($_GET['error'] == "emptyfield"){
        echo '<p style="color:red;"> Pleased fill all the field below </p>';
    }
}
  ?>
  <div class="form-group">
    <label for="project_title">Project title</label>
    <input type="text" class="form-control" name="project_title"  placeholder="Enter Project Title" >
    </div>
	<div class="form-group">
    <label for="project_description">Project description</label>
    <input type="text" class="form-control" name="project_description"  placeholder="Enter Project description">
    </div>
 	<div class="form-group">
    <label for="due_date">Due Date</label>
    <input type="date" class="form-control" name="due_date" placeholder="Pick Due Date">
    </div>
    <div class="form-group">
    <label for="status">Select Status</label>
    <select class="form-control" name="status" id="status">
      <option>Pending</option>
      <option>Active</option>
      <option>Ongoing</option>
      <option>Completed</option>
      </select>
  </div>

    <button type="submit" name="createpro" class="btn btn-primary">Create Project</button> 
</form>


<?php include 'include/footer.php' ?>
   