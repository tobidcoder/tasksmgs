<?php 
require_once("include/autoload.php");
include 'include/header.php';
if(ISSET($_GET['proid']));
$project_id = ($_GET['proid']);
$tasks = new Tasks();
?>
<table class="table">
 <thead class="thead-dark">
 <br>
<a href="createtasks.php"><button class="btn btn-primary btn-xs">Create Tasks<span class="glyphicon glyphicon-pencil"></span></button></a> </td>
   <tr>     
      <th scope="col">Tasks Title</th>
      <th scope="col">Tasks Description</th>
      <th scope="col">Project Title</th>
      <th scope="col">Status</th>
      <th scope="col"> Edit </th>
      <th scope="col"> Delete</th>
      </tr>
  </thead>
  <tbody>
    <?php 
    $tasksview = $tasks->viewTaskspro($project_id);
    foreach ($tasksview as $view){ 
       
    ?>
    <tr>     
      <td><?php echo htmlentities($view['tasks_title']); ?></td>
      <td><?php echo htmlentities($view['tasks_description']);?></td>
      <th><?php echo htmlentities($view['project_title']); ?></td> 
      <td><?php echo htmlentities($view['tasks_status']); ?></td>
      
      <td><a href="edittasks.php?id=<?php echo htmlentities($view['tasks_id']);?>"><button class="btn btn-primary btn-xs">Edit<span class="glyphicon glyphicon-pencil"></span></button></a> </td>
      <td><a href="process.php?delt=<?php echo htmlentities($view['tasks_id']);?>"><button class="btn btn-danger btn-xs" onClick="return confirm('Do you really want to delete this tasks?');">Delete<span class="glyphicon glyphicon-trash"></span></button></a></td>
    </tr>
    <?php  }  ?>    
  </tbody>
</table>
<?php include 'include/footer.php' ?>
   