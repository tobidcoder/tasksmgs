<?php
require_once("include/autoload.php");
include 'include/header.php';
//Delete project
if(isset($_GET['delp'])){
    // Getting deleting row
    $id = ($_GET['delp']);
    $deletepro = new Project();
    $sqldel = $deletepro->deleteProjet($id);
    if ($sqldel){
        // Message for successfull delete
        echo '<script> alert("Project delete successful"); </script>';
        echo "<script> setTimeout(\"location.href='viewproject.php';\",15);</script>";
    }
}
?>