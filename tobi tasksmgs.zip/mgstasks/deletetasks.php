<?php
session_start();
require_once("include/autoload.php");
//Dellete Tasks
if(isset($_GET['delt'])){
    // Getting deleting row
    $id = ($_GET['delt']);
    $deletasks = new Tasks();
    $sqldel = $deletasks->deleteTasks($id);
    if ($sqldel){
        // Message for successfull Delete
        echo '<script> alert("Tasks deleted successful"); </script>';
        echo "<script> setTimeout(\"location.href='viewtasks.php';\",15);</script>";
    }else {
        echo '<script> alert("something went wrongs, pleased try again"); </script>';
        echo "<script> setTimeout(\"location.href='viewtasks.php';\",15);</script>";
    }
}
?>
<?php include 'include/footer.php' ?>