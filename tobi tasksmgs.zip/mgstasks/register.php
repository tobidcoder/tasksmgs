<?php 
session_start();
require_once ("include/autoload.php");
//check if already login 
if(isset($_SESSION['id'])){
  header("location: dashboard.php");
}

// Escape user inputs for security
$user = new User();
if(ISSET($_POST['register'])){
  $fname =strip_tags(trim($_POST['fname']));
  $lname =strip_tags(trim($_POST['lname']));
  $email =strip_tags(trim($_POST['email']));
  $username =strip_tags(trim($_POST['username']));
  $password =strip_tags(trim($_POST['password']));

  if(empty($fname) || empty($lname) || empty ($email) || empty($username) || empty($password)){
    header("location: register.php?error=emptyfield&fname=".$fname."&lname=".$lname."&email=".$email."&username=".$username);
   exit();
  } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/",$fname, $lname, $username)){
    header("location: register.php?error=Invalidfnamelnameemailusername");
    exit();
  }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
    header("location: register.php?error=Invalidemail&fname=".$fname."&lname=".$lname."&username=".$username);
   exit();
  }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$fname)){
    header("location: register.php?error=Invalidfirstname&lname=".$lname."&email=".$email."&username=".$username);
   exit();
  }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$lname)){
    header("location: register.php?error=Invalidlastname&fname=".$fname."&email=".$email."&username=".$username);
   exit();
  }elseif(!preg_match("/^[a-zA-Z0-9]*$/",$username)){
    header("location: register.php?error=Invalidusername&fname=".$fname."&lname=".$lname."&email=".$email);
  exit();
}else {
  $register=$user->userRegister($fname,$lname,$email,$username,$password);
  if(!$register){
    //If Registration is Valid
      header("location: register.php?error=registernotsucess");
    }else{
      header("location: register.php?sucess=registrationsucessful");
    }
} 
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="include/css/style.css">
    <title>Registration Page</title>
  </head>
  <body>

  <form class="tobi-form" action="" method="POST">
  <h3> USER REGISTER PAGE </h3>
  <?php
  if(isset($_GET['error'])){
      if($_GET['error']  == "emptyfield") {
        echo '<p style="color:red;"> One or more field need to be fill </p>';
      }elseif($_GET['error'] == "Invalidfnamelnameemailusername"){
        echo '<p style="color:red;"> Pleased enter a valid value in th field </p>';
      }elseif($_GET['error'] == "Invalidemail"){
        echo '<p style="color:red;"> Pleased enter a valid email address</p>';
      }elseif($_GET['error'] == "Invalidfirstname"){
        echo '<p style="color:red;"> Pleased enter a valid first name</p>';
      }elseif($_GET['error'] == "Invalidlastname"){
        echo '<p style="color:red;"> Pleased enter a valid last name</p>';
      }elseif($_GET['error'] == "Invalidusername"){
        echo '<p style="color:red;"> Pleased enter a valid user name</p>';
      }elseif($_GET['error'] == "registernotsucess"){
        echo '<p style="color:red;">something went rong registration not succesful</p>';
      }
  }
  if(isset($_GET['sucess'])){
  if($_GET['sucess'] == "registrationsucessful"){
    echo '<p style="color:green;">You have succesful register: Click here to <a  href="login.php"> Login </a></p>';
  }
}
    ?>
  <div class="form-group">
    <label for="fname">First Name</label>
    <input type="text" class="form-control" name="fname"  placeholder="Enter Fisrt name" >
    </div>
	<div class="form-group">
    <label for="lname">Last Name</label>
    <input type="text" class="form-control" name="lname"  placeholder="Enter Last Name" >
    </div>
	<div class="form-group">
    <label for="fname">Email address</label>
    <input type="email" class="form-control" name="email"  placeholder="Enter email" >
    </div>
	<div class="form-group">
    <label for="Username">Username</label>
    <input type="text" class="form-control" name="username" placeholder="Enter Username" >
    </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" name="password"  placeholder="Password">
  </div>  
  <button type="submit" name="register" class="btn btn-primary">Register</button>
  <p> Already have an account <a href="login.php">Login </a> </p>
</form>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>