
<?php
include 'include/header.php';
//die("I am here");
require_once("include/autoload.php");
 //Get number of project for user
 $projnum = new Project();
 $result = $projnum->numofProject();

 $num = mysqli_num_rows($result);
//Get number of tasks for user
$tasksnum = new Tasks();
$result = $tasksnum->numofTasks();
$count = mysqli_num_rows($result);
?>
<br>
<div class="row">
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h1 class="card-title">Project</h1>
        <h4 class="card-text">You have <b> <?php echo $num; ?> </b>Projects.</h4>
        <br>
        <a href="createproject.php" class="btn btn-primary">Create Project</a>
        <a href="viewproject.php" class="btn btn-primary">View Project</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h1 class="card-title">Tasks</h1>
        <h4 class="card-text">You have <b> <?php echo $count; ?> </b>Tasks.</h4>
        <br>
        <a href="createtasks.php" class="btn btn-primary">Create Tasks</a>
        <a href="viewtasks.php" class="btn btn-primary">View Tasks</a>
      </div>
    </div>
  </div>
</div>
<?php include 'include/footer.php' ?>  
