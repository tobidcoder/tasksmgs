<?php 
require_once("include/autoload.php");
include 'include/header.php';
//Create task
$tasks = new Tasks();
$project =new Project();
$db = new Db ();
if(ISSET($_POST['createtasks'])){
    $tasks_title = strip_tags(mysqli_real_escape_string($db->connect(),$_POST['tasks_title']));
    $tasks_description = strip_tags(mysqli_real_escape_string($db->connect(),$_POST['tasks_description']));
    $project_id = strip_tags(mysqli_real_escape_string($db->connect(),$_POST['project_id']));
    $tasks_status = strip_tags(mysqli_real_escape_string($db->connect(),$_POST['tasks_status'])); 

if(empty($tasks_title) || empty($tasks_description) || empty($project_id) || empty($tasks_status)){
  header("location: createtasks.php?error=emptyfield&taskstitle=".$tasks_title."&tasksdescription=".$tasks_description."&tasksstatus=".$tasks_status);
  exit();
}else {
  $addtasks = $tasks->createTasks($tasks_title,$tasks_description,$project_id,$tasks_status);
  if(!$addtasks){
    echo '<script> alert ("something went wrong, pleased try again")</script>';
    echo '<script>window.location="createtasks.php"<script>';
      } else {
    echo '<script> alert ("Tasks added successful")</script>';
    echo '<script>window.location = "viewtasks.php"</script>';
       }
}
} 
?>
<form class="tobi-form" action="" method="POST">
  <h3> Create Tasks </h3>
  <?php 
  if(isset($_GET['error'])){
    if($_GET['error'] == "emptyfield"){
      echo '<p style="color:red;"> All field are required </p>';
   }
  }
  ?>
  <div class="form-group">
    <label for="tasks_title">Tasks title</label>
    <input type="text" class="form-control" name="tasks_title"  placeholder="Enter Tasks Title" >
    </div>
	<div class="form-group">
    <label for="tasks_description">Tasks description</label>
    <input type="text" class="form-control" name="tasks_description"  placeholder="Enter Tasks description" >
    </div>     
    <div class="form-group">
    <label for="Project_id">Project Tasks</label>      
    <select class="form-control" name="project_id" id="Project_id">
      <option value="">-select- </option> 
    <?php
      $titles = $project->viewProject();
      foreach($titles as $title)
       {          
         echo "<option value='".$title['id']."'>";
         echo htmlentities($title['project_title']);
         echo "</option>";
       }
    ?>    
      </select>
  </div>   
    <div class="form-group">
    <label for="tasks_status">Select Status</label>
    <select class="form-control" name="tasks_status" id="tasks_status">
      <option>Pending</option>
      <option>Active</option>
      <option>Ongoing</option>
      <option>Completed</option>
      </select>
  </div>
    <button type="submit" name="createtasks" class="btn btn-primary">Create Tasks</button> 
</form>
<?php include 'include/footer.php' ?>
   